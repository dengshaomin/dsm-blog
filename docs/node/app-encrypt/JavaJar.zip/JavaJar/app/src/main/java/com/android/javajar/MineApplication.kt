package com.android.javajar

import android.app.Application
import android.content.Context
import android.util.Log

class MineApplication: Application() {
    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        log("call source apk attachBaseContext")
    }

    override fun onCreate() {
        super.onCreate()
        log("call source apk onCreate")
    }
    private fun log(msg: String) {
        Log.e("unshell", msg)
    }
}