package com.android.jiagu.tools

import org.w3c.dom.Document
import org.w3c.dom.Element
import org.xml.sax.SAXException
import java.io.IOException
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.parsers.ParserConfigurationException
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerException
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

/**
 * Created by zoulong on 2019/2/26 0026.
 */
object AndroidXmlUtils {
    private const val NS = "http://schemas.android.com/apk/res/android"
    @Throws(ParserConfigurationException::class, IOException::class, SAXException::class)
    fun readApplicationName(manifestPath: String?): String? {
        val factory = DocumentBuilderFactory.newInstance()
        factory.isValidating = true
        factory.isNamespaceAware = true
        val builder = factory.newDocumentBuilder()
        val document = builder.parse(manifestPath)
        val element = document.documentElement
        val applicationElement = element.getElementsByTagName("application").item(0) as Element
        return if (applicationElement.hasAttributeNS(NS, "name")) {
            applicationElement.getAttributeNodeNS(NS, "name").value
        } else {
            null
        }
    }

    @Throws(
        ParserConfigurationException::class,
        IOException::class,
        SAXException::class,
        TransformerException::class
    )
    fun changeApplicationName(manifestPath: String, newName: String?) {
        val factory = DocumentBuilderFactory.newInstance()
        factory.isValidating = true
        factory.isNamespaceAware = true
        val builder = factory.newDocumentBuilder()
        val document = builder.parse(manifestPath)
        val element = document.documentElement
        val applicationElement = element.getElementsByTagName("application").item(0) as Element
        if (applicationElement.hasAttribute("name")) {
            applicationElement.getAttributeNodeNS(NS, "name").value = newName
        } else {
            applicationElement.setAttribute("android:name", newName)
        }
        writeXmlToLocal(document, manifestPath)
    }

    @Throws(
        ParserConfigurationException::class,
        IOException::class,
        SAXException::class,
        TransformerException::class
    )
    fun addMateData(manifestPath: String, name: String?, value: String?) {
        val factory = DocumentBuilderFactory.newInstance()
        factory.isValidating = true
        factory.isNamespaceAware = true
        val builder = factory.newDocumentBuilder()
        val document = builder.parse(manifestPath)
        val element = document.documentElement
        val applicationElement = element.getElementsByTagName("application").item(0) as Element
        val mateDataElement = document.createElement("meta-data")
        mateDataElement.setAttribute("android:name", name)
        mateDataElement.setAttribute("android:value", value)
        applicationElement.appendChild(mateDataElement)
        writeXmlToLocal(document, manifestPath)
    }

    @Throws(TransformerException::class)
    private fun writeXmlToLocal(document: Document, outXmlPath: String) {
        val tff = TransformerFactory.newInstance()
        val tf = tff.newTransformer()
        tf.setOutputProperty(OutputKeys.INDENT, "yes")
        tf.transform(DOMSource(document), StreamResult(outXmlPath))
    }
}