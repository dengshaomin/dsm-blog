package com.android.jiagu.tools

import cn.hutool.core.io.FileUtil
import cn.hutool.crypto.SecureUtil
import com.android.jiagu.JiaGu
import com.android.jiagu.tools.ApkToolUtils.compile
import com.android.jiagu.tools.ApkToolUtils.decompile
import com.android.jiagu.tools.SignUtils.V1
import com.android.jiagu.tools.SignUtils.defaultKeystore
import java.io.File

object ApkShellUtils {
    fun apkShell(sourceApkPath: String, unShellApkPath: String, outApkPath: String) {
        //解压原apk
        val sourceApkDstPath = sourceApkPath.replace(".apk", "")
        FileUtil.del(sourceApkDstPath)
        decompile(sourceApkPath, sourceApkDstPath)
        val primaryManifestPath = sourceApkDstPath + File.separator + "AndroidManifest.xml"

        //解压解壳apk
        val unShellApkDstPath = unShellApkPath.replace(".apk", "")
        FileUtil.del(unShellApkDstPath)
        decompile(unShellApkPath, unShellApkDstPath)
        val unShellManifestPath = unShellApkDstPath + File.separator + "AndroidManifest.xml"
        val unShellDexPath = unShellApkDstPath + File.separator + "classes.dex"
        val unShellFile = File(unShellDexPath)
        val unApkDir = File(sourceApkDstPath)
        val dexArray = ArrayList<File>()
        for (file in unApkDir.listFiles()) { //读取解壳后的dex
            if (file.name.endsWith(".dex")) {
                dexArray.add(file)
            }
        }
        //合并所有dex
        mergeDex(dexArray, unShellFile)
        val mateInfPath = sourceApkDstPath + File.separator + "META-INF"
        //删除meta-inf，重新签名后会生成
        FileUtil.del(mateInfPath)
        //获取壳ApplicationName
        val unShellApplicationName =
            AndroidXmlUtils.readApplicationName(unShellManifestPath)
        //获取原applicationName
        val sourceApplicationName =
            AndroidXmlUtils.readApplicationName(primaryManifestPath)
        //改变原Applicationname为壳ApplicationName
        AndroidXmlUtils.changeApplicationName(
            primaryManifestPath,
            unShellApplicationName
        )
        //将原ApplicationName写入mateData中，解壳application中会读取并替换应用Application
        if (sourceApplicationName != null) {
            AndroidXmlUtils.addMateData(
                primaryManifestPath,
                "APPLICATION_CLASS_NAME",
                sourceApplicationName
            )
        }
        //apk回编
        compile(sourceApkDstPath, outApkPath)
        //v1签名
        V1(outApkPath, defaultKeystore)
        //由于使用的是v1签名(jarsigner)，所以在签名之后进行对齐
        ZipAlign.zipalign(outApkPath)
        //清理目录
        FileUtil.del(sourceApkDstPath)
        FileUtil.del(unShellApkDstPath)
    }

    private fun mergeDex(sourceDex: ArrayList<File>, unShellDex: File) {
        sourceDex.sortByDescending { it.name }
        sourceDex.map { file ->
            //0,2,3,4
            val ts = file.name.replace("classes", "").replace(".dex", "")
            var newIndex = if (ts.isNullOrEmpty()) 2 else ts.toInt() + 1
            val newName = "${file.parent}/classes${newIndex}.dex"
            val encryptBytes =
                SecureUtil.aes(JiaGu.AES_KEY.toByteArray()).encrypt(FileUtil.readBytes(file))
            FileUtil.writeBytes(encryptBytes, newName)
        }
        //将壳的dex改为默认启动的dex,提高dex的遍历效率
        FileUtil.copy(
            unShellDex.absolutePath,
            File(sourceDex[0].parent, "classes.dex").absolutePath,
            true
        )
    }
}