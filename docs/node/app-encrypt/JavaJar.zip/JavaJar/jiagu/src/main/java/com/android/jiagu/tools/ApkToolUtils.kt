package com.android.jiagu.tools

import com.android.jiagu.JiaGu.APKTOOL_PATH
import java.io.IOException

object ApkToolUtils {


    @JvmStatic
    @Throws(IOException::class, InterruptedException::class)
    fun decompile(apkPath: String, outPath: String): Boolean {
        var cmd = "java -jar %s -s d %s -o %s"
        cmd = String.format(cmd, *arrayOf<Any>(APKTOOL_PATH!!, apkPath, outPath))
        CmdExecutor.executor(cmd)
        return true
    }

    @JvmStatic
    @Throws(IOException::class, InterruptedException::class)
    fun compile(apkDir: String, outPath: String): Boolean {
        var cmd = "java -jar %s b %s -o %s"
        cmd = String.format(cmd, *arrayOf<Any>(APKTOOL_PATH!!, apkDir, outPath))
        CmdExecutor.executor(cmd)
        return true
    }
}