package com.android.jiagu.tools

import cn.hutool.core.io.FileUtil
import com.android.jiagu.JiaGu
import java.io.File

object ZipAlign {

    fun zipalign(apkPath: String) {
        val file = File(apkPath)
        val newPath = File(file.parent, "zipalign_${file.name}").absolutePath
        CmdExecutor.executor("${JiaGu.ZIPALIGN_PATH} -v -p  4 ${apkPath} ${newPath}")
        FileUtil.rename(File(newPath), apkPath, true)
    }
}