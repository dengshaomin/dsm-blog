package com.android.jiagu.tools

import com.android.jiagu.JiaGu.KEYSTORE_PATH
import com.android.jiagu.JiaGu.keystore_aliasName
import com.android.jiagu.JiaGu.keystore_aliasPassword
import com.android.jiagu.JiaGu.keystore_name
import com.android.jiagu.JiaGu.keystore_password
import java.io.IOException

object SignUtils {
    @JvmStatic
    @Throws(IOException::class, InterruptedException::class)
    fun V1(apkPath: String?, keystore: Keystore) {
        var cmd =
            "jarsigner -verbose -keystore %s -storepass %s -keypass %s %s %s -digestalg SHA1 -sigalg SHA1withRSA"
        cmd = String.format(
            cmd,
            *arrayOf<Any?>(
                keystore.path,
                keystore.aliasPassword,
                keystore.password,
                apkPath,
                keystore.aliasName
            )
        )
        CmdExecutor.executor(cmd)
    }

    @JvmStatic
    val defaultKeystore: Keystore
        get() {
            val keystore = Keystore()
            keystore.path = KEYSTORE_PATH
            keystore.name = keystore_name
            keystore.aliasName = keystore_aliasName
            keystore.password = keystore_password
            keystore.aliasPassword = keystore_aliasPassword
            return keystore
        }

    class Keystore {
        var path: String? = null
        var name: String? = null
        var password: String? = null
        var aliasName: String? = null
        var aliasPassword: String? = null
    }
}