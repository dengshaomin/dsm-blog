package com.android.jiagu

import cn.hutool.core.io.FileUtil
import com.android.jiagu.tools.ApkShellUtils
import java.io.File

object JiaGu {
    const val AES_KEY = "gH3p9sR6wQ2dE5fT"
    var APKTOOL_PATH: String? = null
    var KEYSTORE_PATH: String? = null
    var keystore_name: String? = null
    var keystore_aliasName: String? = null
    var keystore_password: String? = null
    var keystore_aliasPassword: String? = null
    var ZIPALIGN_PATH: String? = null

    @JvmStatic
    fun main(args: Array<String>) {
        var inPath: String? = null
        var outPath: String? = null
        var unShellPath: String? = null
        args.map {
            inPath = findParams(args, "-i")
            outPath = findParams(args, "-o")
            unShellPath = findParams(args, "-u")
            ZIPALIGN_PATH = findParams(args,"-zipalign")
            APKTOOL_PATH = findParams(args, "-apktool")
            KEYSTORE_PATH = findParams(args, "-keystore")
            keystore_name = findParams(args, "-keystore.name")
            keystore_aliasName = findParams(args, "-keystore.aliasName")
            keystore_password = findParams(args, "-keystore.password")
            keystore_aliasPassword = findParams(args, "-keystore.aliasPassword")
        }
        if (!File(inPath).exists() || !File(inPath).name.endsWith(".apk")) {
            throw RuntimeException("-i params not available")
        }
        if (!File(unShellPath).exists() || !File(unShellPath).name.endsWith(".apk")) {
            throw RuntimeException("-u params not available")
        }
        if (!File(outPath).name.endsWith(".apk")) {
            throw RuntimeException("-o params not available")
        }
        if (!File(KEYSTORE_PATH).exists()) {
            throw RuntimeException("-keystore params not available")
        }
        if (!File(APKTOOL_PATH).exists()) {
            throw RuntimeException("-apktool params not available")
        }
        FileUtil.del(outPath)
        ApkShellUtils.apkShell(
            inPath!!,
            unShellPath!!,
            outPath!!
        )
    }

    fun findParams(args: Array<String>, name: String): String? {
        args.map {
            if (it.startsWith(name)) {
                val array = it.split("=")
                if (array.size > 1) {
                    return array[1]
                }
            }
        }
        return null
    }
}