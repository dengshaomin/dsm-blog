package com.android.jiagu.tools

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader

object CmdExecutor {
    @JvmOverloads
    @Throws(IOException::class, InterruptedException::class)
    fun executor(executeStr: String, character: String? = "GB2312"): Boolean {
        println("执行命令：$executeStr")
        val p = Runtime.getRuntime().exec(executeStr)
        val errorGobbler = StreamGobbler(p.errorStream, character)
        errorGobbler.start()
        val outGobbler = StreamGobbler(p.inputStream, character)
        outGobbler.start()
        val executorResultCode = p.waitFor()
        println("进程执行返回值：$executorResultCode")
        if (executorResultCode != 0) {
            println(
                """
    操作系统错误代码0：成功
    操作系统错误代码1：操作不允许
    操作系统错误代码2：没有这样的文件或目录
    操作系统错误代码3：没有这样的过程
    操作系统错误代码4：中断的系统调用
    操作系统错误代码5：输入/输出错误
    操作系统错误代码6：没有这样的设备或地址
    操作系统错误代码7：参数列表太长
    操作系统错误代码8：执行格式错误
    操作系统错误代码9：坏的文件描述符
    操作系统错误代码10：无子过程
    """.trimIndent()
            )
        }
        return executorResultCode == 0
    }

    private class StreamGobbler(private val `is`: InputStream, private val character: String?) :
        Thread() {
        override fun run() {
            var isr: InputStreamReader? = null
            var br: BufferedReader? = null
            try {
                isr = InputStreamReader(`is`, character)
                br = BufferedReader(isr)
                var line: String? = null
                while (br.readLine().also { line = it } != null) {
                    println(line)
                }
            } catch (ioe: IOException) {
                ioe.printStackTrace()
            } finally {
                try {
                    br!!.close()
                    isr!!.close()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}