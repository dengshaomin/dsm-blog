package com.android.unshellapp;

import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.ArrayMap;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.ZipUtil;
import cn.hutool.crypto.SecureUtil;

public class UnShellApplication extends Application {
    private final String AES_KEY = "gH3p9sR6wQ2dE5fT";

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        long startTime = System.currentTimeMillis();
        File apkFile = new File(getApplicationInfo().sourceDir);
        File sourceDir = new File(getCacheDir(), "apk/source");
        File decryptDirs = new File(getCacheDir(), "apk/decrypt");
        List<File> loadDex = new ArrayList<>();
        ZipUtil.unzip(apkFile, sourceDir);
        for (int i = 0; i < sourceDir.listFiles().length; i++) {
            File file = sourceDir.listFiles()[i];
            if (file.getName().endsWith(".dex") && !file.getName().equals("classes.dex")) {
                byte[] decryptBytes = SecureUtil.aes(AES_KEY.getBytes()).decrypt(FileUtil.readBytes(file));
                File dest = FileUtil.writeBytes(decryptBytes, new File(decryptDirs, file.getName()));
                loadDex.add(dest);
            }
        }
        try {
            //6.把解密后的文件加载到系统
            loadDex(loadDex, decryptDirs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        log("decrypt dex const:" + (System.currentTimeMillis() - startTime) + "");
    }

    private void loadDex(List<File> dexFiles, File versionDir) throws Exception {
        //1.先从 ClassLoader 中获取 pathList 的变量
        Field pathListField = ReflectUtils.findField(getClassLoader(), "pathList");
        //1.1 得到 DexPathList 类
        Object pathList = pathListField.get(getClassLoader());
        //1.2 从 DexPathList 类中拿到 dexElements 变量
        Field dexElementsField = ReflectUtils.findField(pathList, "dexElements");
        //1.3 拿到已加载的 dex 数组
        Object[] dexElements = (Object[]) dexElementsField.get(pathList);

        //2. 反射到初始化 dexElements 的方法，也就是得到加载 dex 到系统的方法
        Method makeDexElements = ReflectUtils.findMethod(pathList, "makePathElements", List.class, File.class, List.class);
        //2.1 实例化一个 集合  makePathElements 需要用到
        ArrayList<IOException> suppressedExceptions = new ArrayList<IOException>();
        //2.2 反射执行 makePathElements 函数，把已解码的 dex 加载到系统，不然是打不开 dex 的，会导致 crash
        Object[] addElements = (Object[]) makeDexElements.invoke(pathList, dexFiles, versionDir, suppressedExceptions);

        //3. 实例化一个新数组，用于将当前加载和已加载的 dex 合并成一个新的数组
        Object[] newElements = (Object[]) Array.newInstance(dexElements.getClass().getComponentType(), dexElements.length + addElements.length);
        //3.1 将系统中的已经加载的 dex 放入 newElements 中
        System.arraycopy(dexElements, 0, newElements, 0, dexElements.length);
        //3.2 将解密后已加载的 dex 放入新数组中
        System.arraycopy(addElements, 0, newElements, dexElements.length, addElements.length);

        //4. 将合并的新数组重新设置给 DexPathList的 dexElements
        dexElementsField.set(pathList, newElements);
    }

    @Override
    public void onCreate() {
        loadSourceApplication();
        super.onCreate();
    }

    private void loadSourceApplication() {
        try {
            String appClassName = null;
            ApplicationInfo ai = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            if (bundle != null && bundle.containsKey("APPLICATION_CLASS_NAME")) {
                appClassName = bundle.getString("APPLICATION_CLASS_NAME");
            } else {
                return;
            }
            log("source apk application:" + appClassName);
            // 有值的话调用该Applicaiton
            Object currentActivityThread = ReflectUtils.invokeStaticMethod(
                    "android.app.ActivityThread", "currentActivityThread",
                    new Class[]{}, new Object[]{});
            Object mBoundApplication = ReflectUtils.getFieldOjbect(
                    "android.app.ActivityThread", currentActivityThread,
                    "mBoundApplication");
            Object loadedApkInfo = ReflectUtils.getFieldOjbect(
                    "android.app.ActivityThread$AppBindData",
                    mBoundApplication, "info");
            // 把当前进程的mApplication 设置成了null
            ReflectUtils.setFieldOjbect("android.app.LoadedApk", "mApplication",
                    loadedApkInfo, null);
            Object oldApplication = ReflectUtils.getFieldOjbect(
                    "android.app.ActivityThread", currentActivityThread,
                    "mInitialApplication");
            // http://www.codeceo.com/article/android-context.html
            ArrayList<Application> mAllApplications = (ArrayList<Application>) ReflectUtils
                    .getFieldOjbect("android.app.ActivityThread",
                            currentActivityThread, "mAllApplications");
            mAllApplications.remove(oldApplication);// 删除oldApplication

            ApplicationInfo appinfo_In_LoadedApk = (ApplicationInfo) ReflectUtils
                    .getFieldOjbect("android.app.LoadedApk", loadedApkInfo,
                            "mApplicationInfo");
            ApplicationInfo appinfo_In_AppBindData = (ApplicationInfo) ReflectUtils
                    .getFieldOjbect("android.app.ActivityThread$AppBindData",
                            mBoundApplication, "appInfo");
            appinfo_In_LoadedApk.className = appClassName;
            appinfo_In_AppBindData.className = appClassName;
            Application app = (Application) ReflectUtils.invokeMethod(
                    "android.app.LoadedApk", "makeApplication", loadedApkInfo,
                    new Class[]{boolean.class, Instrumentation.class},
                    new Object[]{false, null});// 执行
            // makeApplication（false,null）
            ReflectUtils.setFieldOjbect("android.app.ActivityThread",
                    "mInitialApplication", currentActivityThread, app);

            Iterator it;
            if (Build.VERSION.SDK_INT < 19) {
                // 解决了类型强转错误的问题，原因：
                // 4.4以下系统 mProviderMap 的类型是 HashMap
                // 4.4以上系统 mProviderMap 的类型是 ArrayMap
                HashMap mProviderMap = (HashMap) ReflectUtils.getFieldOjbect(
                        "android.app.ActivityThread", currentActivityThread,
                        "mProviderMap");
                it = mProviderMap.values().iterator();
            } else {
                ArrayMap mProviderMap = (ArrayMap) ReflectUtils.getFieldOjbect(
                        "android.app.ActivityThread", currentActivityThread,
                        "mProviderMap");
                it = mProviderMap.values().iterator();
            }
            while (it.hasNext()) {
                Object providerClientRecord = it.next();
                Object localProvider = ReflectUtils.getFieldOjbect(
                        "android.app.ActivityThread$ProviderClientRecord",
                        providerClientRecord, "mLocalProvider");
                ReflectUtils.setFieldOjbect("android.content.ContentProvider",
                        "mContext", localProvider, app);
            }
            app.onCreate();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void log(String msg) {
        Log.e("unshell", msg);
    }
}
