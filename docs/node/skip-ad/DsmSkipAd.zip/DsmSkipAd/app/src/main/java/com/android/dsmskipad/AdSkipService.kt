package com.android.dsmskipad

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.blankj.utilcode.util.AppUtils
import com.blankj.utilcode.util.AppUtils.AppInfo
import com.blankj.utilcode.util.LogUtils
import java.util.concurrent.Executors

class AdSkipService : AccessibilityService() {
    private val installApps = mutableListOf<AppInfo>()
    private var workingApps = mutableMapOf<AppInfo,Boolean>()
    private val jumpTexts = mutableListOf<String>().apply {
        add("跳过")
    }
    private val executorService by lazy {
        Executors.newFixedThreadPool(5)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val appInfo = installApps.find { it.packageName == event?.packageName } ?: return
        if(!workingApps.containsKey(appInfo) || event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED){
            workingApps[appInfo] = true
        }else if(workingApps[appInfo] == false){
            return
        }
        var root: AccessibilityNodeInfo? = null
        when (event?.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
//                workingApps[appInfo] = true
                root = this.rootInActiveWindow
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                root = event?.source
                workingApps[appInfo] = false
            }
        }
        executorService.submit {
            loopNode(root)
        }
    }

    private fun loopNode(node: AccessibilityNodeInfo?): Boolean {
        node?.let {
            if (checkAndClick(it)) {
                return true
            }
            for (i in 0 until it.childCount) {
                val result = loopNode(it.getChild(i))
                if (result) {
                    return true
                }
            }
        }
        return false
    }

    private fun checkAndClick(node: AccessibilityNodeInfo): Boolean {
        LogUtils.e(node.text)
        if (jumpTexts.find { node.text?.contains(it) == true } != null) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            return true
        }
        return false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        installApps.clear()
        installApps.addAll(AppUtils.getAppsInfo()
            .filter { !it.isSystem  && it.packageName != AppUtils.getAppPackageName()})
    }

    override fun onUnbind(intent: Intent?): Boolean {
        return super.onUnbind(intent)
        stopSkip()
    }


    override fun onInterrupt() {
        stopSkip()
    }

    private fun stopSkip() {
        executorService.shutdownNow()
    }
}